<?php
// Text
$_['text_title'] = 'SEQR mobile payment';
$_['text_wait'] = 'Please wait!';
$_['text_unavailable'] = 'Payment with SEQR unavailable, please try later.';
